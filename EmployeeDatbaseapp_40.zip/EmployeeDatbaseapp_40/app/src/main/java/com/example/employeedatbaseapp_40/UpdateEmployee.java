package com.example.employeedatbaseapp_40;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateEmployee extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_employee);
    }
}